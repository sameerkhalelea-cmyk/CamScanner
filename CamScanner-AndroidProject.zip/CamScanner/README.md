# CamScanner

A small Android app that scans your home Wi‑Fi subnet for devices that look
like IP cameras / DVRs / NVRs, and lets you open their web interface or RTSP
stream. Intended for auditing your **own** home network — e.g. finding
cameras you forgot about, checking for unexpected devices, or just getting
a quick inventory of what's on your LAN.

## What it does
- Reads your phone's current IP/subnet from Wi‑Fi info (assumes a /24, which
  covers the vast majority of home routers).
- Pings every address in that subnet (multi-threaded, so it's fast).
- For every host that responds, checks a short list of ports commonly used
  by IP cameras and DVR/NVR boxes: 80, 443, 554 (RTSP), 8080, 8000, 8554,
  9000, 2020, 34567, 37777.
- In parallel, sends an ONVIF WS-Discovery probe (UDP multicast) and matches
  any replies back to the IPs found above — this catches ONVIF-compliant
  cameras even if their ports aren't in the list.
- Shows results in a list; tapping one lets you open its web UI (in an
  in-app WebView) or hand off its RTSP URL to an installed player like VLC.

## Why there's no .apk in this response
Building an Android APK requires the Android SDK, build tools, and (for a
first build) downloading Gradle, the Android Gradle Plugin, Kotlin, and the
AndroidX libraries listed in `app/build.gradle` — none of which are
available in the environment that generated this project. This is the full
source, ready to build yourself.

## How to build it (free, a few minutes)
1. Install [Android Studio](https://developer.android.com/studio) if you
   don't have it.
2. File → Open, and select this `CamScanner` folder.
3. Let Gradle sync (it will download everything it needs automatically).
4. Build → Build Bundle(s) / APK(s) → Build APK(s).
5. Android Studio will show a "locate" link to the generated
   `app-debug.apk` — copy that to your phone (e.g. via USB, email, or a
   cloud drive) and open it there to install. You'll need to allow
   "install unknown apps" for whichever app you use to open the file, since
   it isn't from the Play Store.

Alternatively, from a terminal with the SDK set up:
```
cd CamScanner
./gradlew assembleDebug   # (run `gradle wrapper` once first if gradlew is missing)
```
The output lands in `app/build/outputs/apk/debug/app-debug.apk`.

## Permissions it asks for
- **Location** — Android requires this to let an app read Wi-Fi
  connection details (your IP/subnet), even though the app itself does no
  location tracking.
- **Wi-Fi / network state, multicast** — needed to run the scan and listen
  for ONVIF responses.

## Notes / limitations
- Assumes a /24 subnet (255.255.255.0) — true for essentially all
  consumer routers, but if yours uses a non-standard mask you'd need to
  adjust `NetworkScanner.getLocalSubnetPrefix()`.
- RTSP playback is handed off to another installed app (like VLC) rather
  than built in, to keep the project small — the camera's actual stream
  path after `rtsp://ip:554/` varies by manufacturer.
- Only scans the network your phone is currently connected to. Use it on
  networks you own or are authorized to scan.
