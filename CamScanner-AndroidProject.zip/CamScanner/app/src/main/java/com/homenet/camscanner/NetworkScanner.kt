package com.homenet.camscanner

import android.content.Context
import android.net.wifi.WifiManager
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class NetworkScanner(private val context: Context) {

    private val portsToCheck = listOf(80, 443, 554, 8080, 8000, 8554, 9000, 2020, 34567, 37777)

    /** Returns e.g. "192.168.1" for a phone at 192.168.1.42. Assumes a /24 home network. */
    fun getLocalSubnetPrefix(): String? {
        val wifiManager = context.applicationContext
            .getSystemService(Context.WIFI_SERVICE) as WifiManager
        val ipInt = wifiManager.connectionInfo.ipAddress
        if (ipInt == 0) return null
        val ip = String.format(
            "%d.%d.%d.%d",
            ipInt and 0xff,
            ipInt shr 8 and 0xff,
            ipInt shr 16 and 0xff,
            ipInt shr 24 and 0xff
        )
        return ip.substringBeforeLast(".")
    }

    /**
     * Pings every host in the /24 subnet, checks a short list of camera-related
     * TCP ports on anything that answers, and merges in ONVIF WS-Discovery
     * results gathered in parallel. onProgress reports (hostsChecked, total).
     */
    fun scan(onProgress: (Int, Int) -> Unit = { _, _ -> }): List<Device> {
        val prefix = getLocalSubnetPrefix()
            ?: throw IllegalStateException("Not connected to Wi-Fi, or IP unavailable")

        val found = ConcurrentLinkedQueue<Device>()
        val pool = Executors.newFixedThreadPool(32)
        var done = 0

        val onvifFuture = pool.submit<Map<String, String>> {
            OnvifDiscovery(context).discover(timeoutMs = 4000)
        }

        val futures = (1..254).map { host ->
            pool.submit {
                val ip = "$prefix.$host"
                try {
                    val addr = InetAddress.getByName(ip)
                    if (addr.isReachable(300)) {
                        val openPorts = portsToCheck.filter { port -> isPortOpen(ip, port, 300) }
                        if (openPorts.isNotEmpty()) {
                            found.add(Device(ip = ip, openPorts = openPorts))
                        }
                    }
                } catch (_: Exception) {
                    // unreachable host - skip
                } finally {
                    synchronized(this) {
                        done += 1
                        onProgress(done, 254)
                    }
                }
            }
        }
        futures.forEach {
            try { it.get(3, TimeUnit.SECONDS) } catch (_: Exception) { }
        }

        val onvifMap = try {
            onvifFuture.get(5, TimeUnit.SECONDS)
        } catch (_: Exception) {
            emptyMap()
        }

        pool.shutdownNow()

        val byIp = found.associateBy { it.ip }.toMutableMap()
        for ((ip, xaddr) in onvifMap) {
            val existing = byIp[ip]
            byIp[ip] = existing?.copy(isOnvif = true, onvifXAddr = xaddr)
                ?: Device(ip = ip, isOnvif = true, onvifXAddr = xaddr)
        }

        return byIp.values.sortedByDescending { it.likelyCamera }
    }

    private fun isPortOpen(ip: String, port: Int, timeoutMs: Int): Boolean {
        return try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(ip, port), timeoutMs)
                true
            }
        } catch (_: Exception) {
            false
        }
    }
}
