package com.homenet.camscanner

import android.content.Context
import android.net.wifi.WifiManager
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.UUID

/**
 * Minimal WS-Discovery client. Sends a multicast "Probe" for devices of the
 * ONVIF NetworkVideoTransmitter type and collects ProbeMatch responses for
 * a short window. Most modern ONVIF-compliant IP cameras answer this.
 */
class OnvifDiscovery(private val context: Context) {

    fun discover(timeoutMs: Int = 4000): Map<String, String> {
        val wifiManager = context.applicationContext
            .getSystemService(Context.WIFI_SERVICE) as WifiManager
        val multicastLock = wifiManager.createMulticastLock("camscanner-onvif")
        multicastLock.setReferenceCounted(true)
        multicastLock.acquire()

        val results = mutableMapOf<String, String>()
        var socket: DatagramSocket? = null
        try {
            socket = DatagramSocket()
            socket.broadcast = true

            val probe = buildProbeMessage(UUID.randomUUID().toString()).toByteArray()
            val group = InetAddress.getByName("239.255.255.250")
            socket.send(DatagramPacket(probe, probe.size, group, 3702))

            val buffer = ByteArray(8192)
            val deadline = System.currentTimeMillis() + timeoutMs
            while (System.currentTimeMillis() < deadline) {
                try {
                    val remaining = (deadline - System.currentTimeMillis()).toInt().coerceAtLeast(1)
                    socket.soTimeout = remaining
                    val response = DatagramPacket(buffer, buffer.size)
                    socket.receive(response)
                    val text = String(response.data, 0, response.length)
                    extractXAddr(text)?.let { xaddr ->
                        response.address.hostAddress?.let { ip -> results[ip] = xaddr }
                    }
                } catch (_: Exception) {
                    break // timed out or socket closed - stop listening
                }
            }
        } catch (_: Exception) {
            // Multicast may be blocked on some networks/devices - fail quietly.
        } finally {
            socket?.close()
            if (multicastLock.isHeld) multicastLock.release()
        }
        return results
    }

    private fun buildProbeMessage(messageId: String): String = """
        <?xml version="1.0" encoding="UTF-8"?>
        <e:Envelope xmlns:e="http://www.w3.org/2003/05/soap-envelope"
                    xmlns:w="http://schemas.xmlsoap.org/ws/2004/08/addressing"
                    xmlns:d="http://schemas.xmlsoap.org/ws/2005/04/discovery"
                    xmlns:dn="http://www.onvif.org/ver10/network/wsdl">
          <e:Header>
            <w:MessageID>uuid:$messageId</w:MessageID>
            <w:To e:mustUnderstand="true">urn:schemas-xmlsoap-org:ws:2005:04:discovery</w:To>
            <w:Action e:mustUnderstand="true">http://schemas.xmlsoap.org/ws/2005/04/discovery/Probe</w:Action>
          </e:Header>
          <e:Body>
            <d:Probe>
              <d:Types>dn:NetworkVideoTransmitter</d:Types>
            </d:Probe>
          </e:Body>
        </e:Envelope>
    """.trimIndent()

    private fun extractXAddr(xml: String): String? {
        val tag = "XAddrs>"
        val start = xml.indexOf(tag)
        if (start == -1) return null
        val from = start + tag.length
        val end = xml.indexOf('<', from)
        if (end == -1) return null
        return xml.substring(from, end).trim().split(" ").firstOrNull()
    }
}
