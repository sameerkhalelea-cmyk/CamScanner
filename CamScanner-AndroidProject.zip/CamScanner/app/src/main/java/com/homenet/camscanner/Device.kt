package com.homenet.camscanner

data class Device(
    val ip: String,
    val openPorts: List<Int> = emptyList(),
    val isOnvif: Boolean = false,
    val onvifXAddr: String? = null
) {
    val likelyCamera: Boolean
        get() = isOnvif || openPorts.any { it in CAMERA_PORTS }

    val description: String
        get() {
            val parts = mutableListOf<String>()
            if (isOnvif) parts.add("Responded to ONVIF discovery")
            if (openPorts.contains(554) || openPorts.contains(8554)) parts.add("RTSP port open")
            if (openPorts.contains(80) || openPorts.contains(8080)) parts.add("Web UI port open")
            if (openPorts.contains(37777)) parts.add("Dahua-style DVR port")
            if (openPorts.contains(8000)) parts.add("Hikvision-style port")
            if (openPorts.contains(34567)) parts.add("Generic DVR port")
            if (parts.isEmpty()) parts.add("Open ports: ${openPorts.joinToString()}")
            return parts.joinToString(" · ")
        }

    companion object {
        // Ports commonly used by consumer/business IP cameras and NVR/DVR boxes.
        val CAMERA_PORTS = setOf(554, 8554, 80, 8080, 8000, 37777, 34567, 2020, 9000)
    }
}
