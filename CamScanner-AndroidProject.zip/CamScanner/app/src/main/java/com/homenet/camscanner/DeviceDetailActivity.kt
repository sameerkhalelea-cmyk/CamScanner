package com.homenet.camscanner

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class DeviceDetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_device_detail)

        val ip = intent.getStringExtra("ip") ?: return
        val ports = intent.getStringExtra("ports")
            ?.split(",")?.mapNotNull { it.toIntOrNull() } ?: emptyList()
        val isOnvif = intent.getBooleanExtra("onvif", false)

        title = ip

        findViewById<Button>(R.id.buttonOpenWeb).setOnClickListener { openWebInterface(ip, ports) }
        findViewById<Button>(R.id.buttonOpenRtsp).setOnClickListener { openRtspStream(ip) }

        findViewById<TextView>(R.id.textDetail).text = buildString {
            append("IP address: $ip\n")
            append("Open ports: ${ports.joinToString()}\n")
            if (isOnvif) append("Responded to ONVIF discovery\n")
            append("\nIf the device needs a login, use the credentials on its label, or the ")
            append("manufacturer's documented default — and change it if it's still set to that.")
        }
    }

    private fun openWebInterface(ip: String, ports: List<Int>) {
        val port = when {
            ports.contains(80) -> 80
            ports.contains(8080) -> 8080
            else -> ports.firstOrNull() ?: 80
        }
        val intent = Intent(this, WebActivity::class.java)
        intent.putExtra("url", "http://$ip:$port")
        startActivity(intent)
    }

    private fun openRtspStream(ip: String) {
        // Hands off to whatever RTSP-capable app is installed (e.g. VLC).
        // The exact stream path varies by manufacturer (e.g. /stream1, /live/ch0) -
        // check the camera's manual if the root path doesn't work.
        val uri = Uri.parse("rtsp://$ip:554/")
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(
                this,
                "No RTSP-capable app found. Install a player such as VLC to view the stream.",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}
