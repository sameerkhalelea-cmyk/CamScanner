package com.homenet.camscanner

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.homenet.camscanner.databinding.ActivityMainBinding
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: DeviceAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = DeviceAdapter { device -> openDevice(device) }
        binding.recyclerDevices.layoutManager = LinearLayoutManager(this)
        binding.recyclerDevices.adapter = adapter

        binding.buttonScan.setOnClickListener { requestPermissionsAndScan() }
    }

    private fun requestPermissionsAndScan() {
        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) needed.add(Manifest.permission.ACCESS_FINE_LOCATION)

        if (needed.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toTypedArray(), 100)
        } else {
            startScan()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.isNotEmpty() &&
            grantResults.all { it == PackageManager.PERMISSION_GRANTED }
        ) {
            startScan()
        } else {
            Toast.makeText(this, "Location permission is needed to read Wi-Fi info", Toast.LENGTH_LONG).show()
        }
    }

    private fun startScan() {
        binding.buttonScan.isEnabled = false
        binding.progressBar.visibility = View.VISIBLE
        binding.textStatus.text = "Scanning your network..."
        adapter.submitList(emptyList())

        thread {
            try {
                val scanner = NetworkScanner(applicationContext)
                val results = scanner.scan { done, total ->
                    runOnUiThread { binding.textStatus.text = "Scanning... $done / $total" }
                }
                runOnUiThread {
                    adapter.submitList(results)
                    binding.textStatus.text = if (results.isEmpty())
                        "No devices with camera-like ports found."
                    else
                        "Found ${results.size} device(s). Tap one for options."
                    binding.progressBar.visibility = View.GONE
                    binding.buttonScan.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread {
                    binding.textStatus.text = "Scan failed: ${e.message}"
                    binding.progressBar.visibility = View.GONE
                    binding.buttonScan.isEnabled = true
                }
            }
        }
    }

    private fun openDevice(device: Device) {
        val intent = Intent(this, DeviceDetailActivity::class.java)
        intent.putExtra("ip", device.ip)
        intent.putExtra("ports", device.openPorts.joinToString(","))
        intent.putExtra("onvif", device.isOnvif)
        startActivity(intent)
    }
}
